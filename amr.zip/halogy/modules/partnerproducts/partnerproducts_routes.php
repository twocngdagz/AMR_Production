<?php
	
  $route['admin/partner-products/viewall']        = 'partnerproducts/admin/viewall';
  $route['admin/partner-products/add']            = 'partnerproducts/admin/add';
  $route['admin/partner-products/edit/(:num)']    = 'partnerproducts/admin/edit/$1';
  $route['admin/partner-products/delete/(:num)']  = 'partnerproducts/admin/delete/$1';
  
?>