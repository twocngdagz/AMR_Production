<?php

// cms
$route['images/(:any)'] = 'pages/files/images/$1';
$route['gfx/(:any)'] = 'pages/files/gfx/$1';
$route['css/(:any)'] = 'pages/files/css/$1';
$route['js/(:any)'] = 'pages/files/js/$1';
$route['files/(:any)'] = 'pages/files/files/$1';
$route['thumbs/(:any)'] = 'pages/files/thumbs/$1';

?>