{include:header}
  <div id="main-content">
    <div class="container padding-adjust">
      
      {include:account-menu}
      
      <div class="twelve columns">
       
       <h1>Your order has been cancelled</h1>
	
       <p>No payments have been taken and your cart has been emptied.</p>


      </div>
    </div>
  </div>
{include:footer}