{include:header}
  <div id="main-content">
    <div class="container padding-adjust">
      
      {include:account-menu}
      
      <div class="twelve columns">
       
        {page:pagecontent}

        

      </div>
    </div>
  </div>
{include:footer}
    
     