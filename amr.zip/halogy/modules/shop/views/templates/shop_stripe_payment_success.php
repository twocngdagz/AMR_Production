{include:header}
  <div id="main-content">
    <div class="container padding-adjust">
      
      {include:account-menu}
      
      <div class="twelve columns">
       
       <h1>Payment Success</h1>
	
       <p>You should have been sent an email confirming the order details. You will also have received an order number in that email which you can use in any communications that you have with us.</p>
       <p>We will email you once your order has been shipped.</p>


      </div>
    </div>
  </div>
{include:footer}