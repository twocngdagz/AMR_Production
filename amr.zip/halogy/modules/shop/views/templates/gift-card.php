{include:header}
  <div id="main-content">
    <div class="container padding-adjust">
      {if category:banner}
      <div class="category-banner">
        <img src="{site:url}static/uploads/{category:banner}" alt="{category:title}" />
      </div>
      {/if}
      {include:left-sidebar}
      <div class="twelve columns">
        <form name="" method="POST" action="" id="">
          <h1>Coming Soon</h1>
        </form>

      </div>
    </div>
  </div>
  <script type="text/javascript" src="{site:url}static/js/jquery.lightbox.js"></script>
  <link rel="stylesheet" type="text/css" href="{site:url}static/css/lightbox.css" />
{include:footer}